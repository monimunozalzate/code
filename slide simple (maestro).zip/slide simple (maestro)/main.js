$('.xxx-sliders-container').slick({
    slidesToShow: 1,
    prevArrow: $('.prev'),
    nextArrow: $('.next'),
})